import numpy as np
import math
import os
import time
import cv2
import requests


cap = cv2.VideoCapture(0)
#cap = cv2.VideoCapture(1)
i = 0
url = 'http://192.168.1.103:8080/shot.jpg'


while(cap.isOpened()):
    #ret, img = cap.read()
    img_resp = requests.get(url)
    img_arr = np.array(bytearray(img_resp.content),dtype = np.uint8)
    img = cv2.imdecode(img_arr, -1)

    # get hand data from the rectangle sub window on the screen
    cv2.rectangle(img, (300,300), (100,100), (0,255,0),0)
    crop_img = img[100:300, 100:300]

    
    cv2.imshow('Gesture', img)
    #all_img = np.hstack((drawing, crop_img))
    cv2.imshow('Contours',crop_img)

    k = cv2.waitKey(10)
    frame = crop_img
    hsv = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)
    lower_blue = np.array([0, 0, 120])
    upper_blue = np.array([180, 38, 255])
    mask = cv2.inRange(hsv, lower_blue, upper_blue)
    result = cv2.bitwise_and(frame, frame, mask=mask)
    b, g, r = cv2.split(result)  
    filter = g.copy()


    ret,mask = cv2.threshold(filter,10,255, 1)
    frame[ mask == 0] = 255
    cv2.imshow("H", frame)
    

    if i>50:        
        current_name = "N" + str(i-50)
        img_item = current_name+".jpg"
        cv2.imwrite(img_item, frame)
       
    if cv2.waitKey(20) & 0xFF == ord('q'):
        break
    if i==250:
        break
    else:
        i+=1
cap.release()

