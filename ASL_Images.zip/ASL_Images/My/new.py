##import numpy as np
##import cv2
##
##cap = cv2.VideoCapture(0)
##
##kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE,(3,3))
##fgbg = cv2.createBackgroundSubtractorMOG2()
## 
##
##while(1):
##    ret, frame = cap.read()
##
##    fgmask = fgbg.apply(frame)
##    fgmask = cv2.morphologyEx(fgmask, cv2.MORPH_OPEN, kernel)
##
##    cv2.imshow('frame',fgmask)
##    cv2.imwrite('Image.jpg',fgmask)
##    k = cv2.waitKey(30) & 0xff
##    if k == 27:
##        break
##
##cap.release()
##cv2.destroyAllWindows()

import numpy as np
import cv2
import pickle
import os



     

cap =  cv2.VideoCapture(0)
i=0
while(True):
    ret, frame = cap.read()
    frame = cv2.resize(frame, (200,200), interpolation = cv2.INTER_AREA)
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    cv2.imshow('frame', frame)

    if i>50:        
        current_name = "My" + str(i-50)
        img_item = current_name+".jpg"
        cv2.imwrite(img_item, frame)
        cv2.imshow('frame', frame)
    if cv2.waitKey(20) & 0xFF == ord('q'):
        break
    if i==200:
        break
    else:
        i+=1
cap.release()
cv2.destroyAllWindows()
